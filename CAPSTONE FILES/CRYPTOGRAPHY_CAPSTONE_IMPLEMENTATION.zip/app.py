import os
import json
import sqlite3
import secrets
import hashlib
import base64
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, abort
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from sklearn.tree import DecisionTreeClassifier

BASE = Path(__file__).resolve().parent
DB_PATH = BASE / "adaptive_crypto.db"
ENC_DIR = BASE / "storage" / "encrypted"
DEC_DIR = BASE / "storage" / "decrypted"
KEY_DIR = BASE / "storage" / "keys"
ENC_DIR.mkdir(parents=True, exist_ok=True)
DEC_DIR.mkdir(parents=True, exist_ok=True)
KEY_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-only-change-this-secret")

ALLOWED_EXTENSIONS = {
    "txt", "pdf", "doc", "docx", "xls", "xlsx", "csv", "jpg", "jpeg", "png",
    "gif", "zip", "rar", "json", "xml", "ppt", "pptx", "mp3", "mp4"
}

ALGORITHMS = {
    "AES-256-GCM": "AES-256 authenticated encryption",
    "ChaCha20-Poly1305": "ChaCha20 authenticated encryption",
    "Hybrid AES-256 + RSA-2048": "AES-256 for data + RSA-2048 for key protection",
}

SENSITIVITY = {"Low": 0, "Medium": 1, "High": 2}
PRIORITY = {"Speed": 0, "Balanced": 1, "Security": 2}
ALGO_LABELS = ["AES-256-GCM", "ChaCha20-Poly1305", "Hybrid AES-256 + RSA-2048"]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        original_name TEXT NOT NULL,
        stored_name TEXT NOT NULL,
        file_size INTEGER NOT NULL,
        file_type TEXT NOT NULL,
        sensitivity TEXT NOT NULL,
        priority TEXT NOT NULL,
        algorithm TEXT NOT NULL,
        recommendation_reason TEXT NOT NULL,
        nonce TEXT NOT NULL,
        wrapped_key TEXT NOT NULL,
        rsa_wrapped_key TEXT,
        sha256 TEXT NOT NULL,
        encryption_ms REAL NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        action TEXT NOT NULL,
        status TEXT NOT NULL,
        details TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    # Seed an admin account for local demonstration.
    admin = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()
    if not admin:
        conn.execute(
            "INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
            ("admin", generate_password_hash("Admin@123"), "admin", now())
        )
    conn.commit()
    conn.close()

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log_action(user_id, username, action, status="SUCCESS", details=""):
    conn = db()
    conn.execute(
        "INSERT INTO audit_logs(user_id,username,action,status,details,created_at) VALUES(?,?,?,?,?,?)",
        (user_id, username, action, status, details, now())
    )
    conn.commit()
    conn.close()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please sign in to continue.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            abort(403)
        return fn(*args, **kwargs)
    return wrapper

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def file_type(filename):
    return filename.rsplit(".", 1)[1].lower().upper() if "." in filename else "BINARY"

def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()

# ---- Module 2: AI Adaptive Encryption Intelligence Engine ----
# A small, explainable Decision Tree is trained on policy examples.
# The model learns the selection policy instead of hard-coding a single branch.
def build_ai_model():
    # Features: [extension_class, size_class, sensitivity, priority]
    # ext: 0=document/text, 1=image/media, 2=archive/data
    X, y = [], []
    for ext in range(3):
        for size in range(3):
            for sens in range(3):
                for priority in range(3):
                    # Policy used to create training labels:
                    # high security/sensitivity -> hybrid
                    # speed + large files -> ChaCha20
                    # balanced/general -> AES-GCM
                    if sens == 2 and priority >= 1:
                        label = 2
                    elif priority == 0 and size == 2:
                        label = 1
                    elif ext == 1 and priority == 0:
                        label = 1
                    else:
                        label = 0
                    X.append([ext, size, sens, priority])
                    y.append(label)
    model = DecisionTreeClassifier(max_depth=5, random_state=42)
    model.fit(X, y)
    return model

AI_MODEL = build_ai_model()

def extension_class(ext):
    if ext in {"jpg","jpeg","png","gif","mp3","mp4"}:
        return 1
    if ext in {"zip","rar","csv","json","xml"}:
        return 2
    return 0

def size_class(size_bytes):
    if size_bytes < 1 * 1024 * 1024:
        return 0
    if size_bytes < 20 * 1024 * 1024:
        return 1
    return 2

def recommend_algorithm(filename, size_bytes, sensitivity, priority):
    ext = filename.rsplit(".", 1)[1].lower() if "." in filename else "bin"
    features = [[extension_class(ext), size_class(size_bytes), SENSITIVITY[sensitivity], PRIORITY[priority]]]
    pred = int(AI_MODEL.predict(features)[0])
    probs = AI_MODEL.predict_proba(features)[0]
    algorithm = ALGO_LABELS[pred]
    confidence = float(max(probs)) * 100

    reasons = {
        "AES-256-GCM": "Balanced authenticated encryption selected for general-purpose protection.",
        "ChaCha20-Poly1305": "Performance-oriented authenticated encryption selected for speed or larger/media-heavy files.",
        "Hybrid AES-256 + RSA-2048": "Higher protection selected because sensitivity/security requirements favor layered key protection."
    }
    return algorithm, confidence, reasons[algorithm], features[0]

# ---- Module 3: Adaptive Encryption ----
def master_wrap_key():
    # Local-demo key derived from FLASK_SECRET_KEY. In production, use a KMS/HSM.
    return hashlib.sha256(app.secret_key.encode()).digest()

def wrap_key(key):
    aes = AESGCM(master_wrap_key())
    nonce = secrets.token_bytes(12)
    wrapped = nonce + aes.encrypt(nonce, key, b"adaptive-key-wrap-v1")
    return wrapped

def unwrap_key(blob):
    blob = bytes(blob)
    nonce, ciphertext = blob[:12], blob[12:]
    return AESGCM(master_wrap_key()).decrypt(nonce, ciphertext, b"adaptive-key-wrap-v1")

def rsa_paths():
    return KEY_DIR / "private.pem", KEY_DIR / "public.pem"

def ensure_rsa_keys():
    private_path, public_path = rsa_paths()
    if not private_path.exists():
        private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        private_path.write_bytes(private.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption()
        ))
        public_path.write_bytes(private.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo
        ))

def rsa_public():
    _, public_path = rsa_paths()
    return serialization.load_pem_public_key(public_path.read_bytes())

def rsa_private():
    private_path, _ = rsa_paths()
    return serialization.load_pem_private_key(private_path.read_bytes(), password=None)

def encrypt_payload(data, algorithm):
    if algorithm == "AES-256-GCM":
        key = AESGCM.generate_key(bit_length=256)
        nonce = secrets.token_bytes(12)
        ciphertext = AESGCM(key).encrypt(nonce, data, b"adaptive-file-v1")
        return ciphertext, nonce, wrap_key(key), None

    if algorithm == "ChaCha20-Poly1305":
        key = ChaCha20Poly1305.generate_key()
        nonce = secrets.token_bytes(12)
        ciphertext = ChaCha20Poly1305(key).encrypt(nonce, data, b"adaptive-file-v1")
        return ciphertext, nonce, wrap_key(key), None

    if algorithm == "Hybrid AES-256 + RSA-2048":
        key = AESGCM.generate_key(bit_length=256)
        nonce = secrets.token_bytes(12)
        ciphertext = AESGCM(key).encrypt(nonce, data, b"adaptive-file-v1")
        encrypted_key = rsa_public().encrypt(
            key,
            padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                         algorithm=hashes.SHA256(), label=None)
        )
        return ciphertext, nonce, wrap_key(key), encrypted_key

    raise ValueError("Unsupported algorithm")

def decrypt_payload(row, ciphertext):
    algorithm = row["algorithm"]
    key = None

    if algorithm == "Hybrid AES-256 + RSA-2048":
        key = rsa_private().decrypt(
            bytes.fromhex(row["rsa_wrapped_key"]),
            padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                         algorithm=hashes.SHA256(), label=None)
        )
    else:
        key = unwrap_key(bytes.fromhex(row["wrapped_key"]))

    nonce = bytes.fromhex(row["nonce"])
    if algorithm == "ChaCha20-Poly1305":
        return ChaCha20Poly1305(key).decrypt(nonce, ciphertext, b"adaptive-file-v1")
    return AESGCM(key).decrypt(nonce, ciphertext, b"adaptive-file-v1")


def build_aegis_container(row, ciphertext):
    """Create a self-contained .aegis JSON container.
    It contains only non-secret metadata plus ciphertext. Secret keys remain protected
    by the server-side key wrapping/RSA mechanism.
    """
    container = {
        "format": "AEGIS-1",
        "original_name": row["original_name"],
        "file_type": row["file_type"],
        "file_size": row["file_size"],
        "algorithm": row["algorithm"],
        "sensitivity": row["sensitivity"],
        "priority": row["priority"],
        "nonce": row["nonce"],
        "sha256": row["sha256"],
        "wrapped_key": row["wrapped_key"],
        "rsa_wrapped_key": row["rsa_wrapped_key"],
        "ciphertext_b64": base64.b64encode(ciphertext).decode("ascii"),
    }
    return json.dumps(container, indent=2).encode("utf-8")

@app.context_processor
def inject_globals():
    return {"current_user": session.get("username"), "current_role": session.get("role")}

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("landing.html")

# ---- Module 1: User Management & Secure File Upload ----
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 8:
            flash("Username must be 3+ characters and password 8+ characters.", "danger")
            return render_template("register.html")
        conn = db()
        try:
            conn.execute(
                "INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                (username, generate_password_hash(password), "user", now())
            )
            conn.commit()
            flash("Account created. You can now sign in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That username is already registered.", "danger")
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = db()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            log_action(user["id"], user["username"], "LOGIN", "SUCCESS", "Interactive sign-in")
            return redirect(url_for("dashboard"))
        if user:
            log_action(user["id"], user["username"], "LOGIN", "FAILED", "Invalid credentials")
        flash("Invalid username or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    if "user_id" in session:
        log_action(session["user_id"], session["username"], "LOGOUT", "SUCCESS", "User signed out")
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    conn = db()
    user_id = session["user_id"]
    files = conn.execute("SELECT * FROM files WHERE user_id=? ORDER BY id DESC LIMIT 8", (user_id,)).fetchall()
    stats = {
        "files": conn.execute("SELECT COUNT(*) FROM files WHERE user_id=?", (user_id,)).fetchone()[0],
        "encrypted_bytes": conn.execute("SELECT COALESCE(SUM(file_size),0) FROM files WHERE user_id=?", (user_id,)).fetchone()[0],
        "avg_ms": conn.execute("SELECT COALESCE(AVG(encryption_ms),0) FROM files WHERE user_id=?", (user_id,)).fetchone()[0],
        "logs": conn.execute("SELECT COUNT(*) FROM audit_logs WHERE user_id=?", (user_id,)).fetchone()[0],
    }
    usage = conn.execute(
        "SELECT algorithm, COUNT(*) count FROM files WHERE user_id=? GROUP BY algorithm ORDER BY count DESC",
        (user_id,)
    ).fetchall()
    conn.close()
    return render_template("dashboard.html", files=files, stats=stats, usage=usage)

@app.route("/encrypt", methods=["GET", "POST"])
@login_required
def encrypt_file():
    if request.method == "POST":
        uploaded = request.files.get("file")
        sensitivity = request.form.get("sensitivity", "Medium")
        priority = request.form.get("priority", "Balanced")
        if not uploaded or uploaded.filename == "":
            flash("Choose a file to encrypt.", "danger")
            return render_template("encrypt.html")
        if not allowed_file(uploaded.filename):
            flash("File type is not allowed in this demonstration.", "danger")
            return render_template("encrypt.html")
        if sensitivity not in SENSITIVITY or priority not in PRIORITY:
            flash("Invalid security settings.", "danger")
            return render_template("encrypt.html")

        original_name = secure_filename(uploaded.filename)
        data = uploaded.read()
        if len(data) > 50 * 1024 * 1024:
            flash("Maximum demonstration file size is 50 MB.", "danger")
            return render_template("encrypt.html")

        algorithm, confidence, reason, features = recommend_algorithm(
            original_name, len(data), sensitivity, priority
        )

        import time
        start = time.perf_counter()
        ciphertext, nonce, wrapped, rsa_wrapped = encrypt_payload(data, algorithm)
        elapsed = (time.perf_counter() - start) * 1000

        file_id = secrets.token_hex(10)
        stored_name = f"{file_id}.bin"
        (ENC_DIR / stored_name).write_bytes(ciphertext)

        conn = db()
        conn.execute(
            """INSERT INTO files(
                user_id,original_name,stored_name,file_size,file_type,sensitivity,priority,
                algorithm,recommendation_reason,nonce,wrapped_key,rsa_wrapped_key,sha256,
                encryption_ms,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                session["user_id"], original_name, stored_name, len(data), file_type(original_name),
                sensitivity, priority, algorithm, reason, nonce.hex(), wrapped.hex(),
                rsa_wrapped.hex() if rsa_wrapped else None, sha256_bytes(data), elapsed, now()
            )
        )
        conn.commit()
        new_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.close()

        log_action(
            session["user_id"], session["username"], "ENCRYPT",
            "SUCCESS", f"{original_name} → {algorithm} ({confidence:.1f}% AI confidence)"
        )
        return render_template(
            "result.html", file_id=new_id, filename=original_name,
            algorithm=algorithm, confidence=confidence, reason=reason,
            elapsed=elapsed, sensitivity=sensitivity, priority=priority
        )
    return render_template("encrypt.html")

# ---- Module 3: Decryption / secure retrieval ----
@app.route("/files")
@login_required
def files_page():
    conn = db()
    if session.get("role") == "admin":
        rows = conn.execute("SELECT files.*, users.username FROM files JOIN users ON users.id=files.user_id ORDER BY files.id DESC").fetchall()
    else:
        rows = conn.execute("SELECT * FROM files WHERE user_id=? ORDER BY id DESC", (session["user_id"],)).fetchall()
    conn.close()
    return render_template("files.html", files=rows)


@app.route("/save-encrypted/<int:file_id>")
@login_required
def save_encrypted(file_id):
    """Download the actual encrypted AEGIS container."""
    conn = db()
    row = conn.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
    conn.close()
    if not row:
        abort(404)
    if row["user_id"] != session["user_id"] and session.get("role") != "admin":
        abort(403)

    ciphertext_path = ENC_DIR / row["stored_name"]
    if not ciphertext_path.exists():
        abort(404)

    container = build_aegis_container(row, ciphertext_path.read_bytes())
    safe_name = secure_filename(row["original_name"]) or "protected_file"
    download_name = f"{safe_name}.aegis"

    log_action(
        session["user_id"], session["username"], "SAVE_ENCRYPTED",
        "SUCCESS", f"Downloaded ciphertext container {download_name}"
    )
    from io import BytesIO
    return send_file(
        BytesIO(container),
        as_attachment=True,
        download_name=download_name,
        mimetype="application/json"
    )


@app.route("/inspect/<int:file_id>")
@login_required
def inspect_ciphertext(file_id):
    """Show transparent cryptographic metadata and a hex preview of ciphertext."""
    conn = db()
    row = conn.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
    conn.close()
    if not row:
        abort(404)
    if row["user_id"] != session["user_id"] and session.get("role") != "admin":
        abort(403)

    ciphertext_path = ENC_DIR / row["stored_name"]
    if not ciphertext_path.exists():
        abort(404)

    ciphertext = ciphertext_path.read_bytes()
    preview = ciphertext[:96]
    hex_preview = " ".join(f"{b:02x}" for b in preview)
    container_size = len(build_aegis_container(row, ciphertext))

    log_action(
        session["user_id"], session["username"], "INSPECT_CIPHERTEXT",
        "SUCCESS", f"Inspected ciphertext for file {row['original_name']}"
    )

    return render_template(
        "inspect.html",
        file=row,
        ciphertext_size=len(ciphertext),
        container_size=container_size,
        hex_preview=hex_preview,
        preview_bytes=len(preview),
        auth_label=(
            "GCM Authentication Tag"
            if "GCM" in row["algorithm"]
            else "Poly1305 Authentication Tag"
        )
    )

@app.route("/download/<int:file_id>")
@login_required
def download(file_id):
    conn = db()
    row = conn.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
    conn.close()
    if not row:
        abort(404)
    if row["user_id"] != session["user_id"] and session.get("role") != "admin":
        abort(403)

    ciphertext_path = ENC_DIR / row["stored_name"]
    if not ciphertext_path.exists():
        abort(404)

    try:
        plaintext = decrypt_payload(row, ciphertext_path.read_bytes())
    except Exception:
        log_action(session["user_id"], session["username"], "DECRYPT", "FAILED", f"Integrity/decryption failure for file {file_id}")
        abort(500)

    if sha256_bytes(plaintext) != row["sha256"]:
        log_action(session["user_id"], session["username"], "DECRYPT", "FAILED", f"Hash mismatch for file {file_id}")
        abort(500)

    out = DEC_DIR / f"{secrets.token_hex(8)}_{row['original_name']}"
    out.write_bytes(plaintext)
    log_action(session["user_id"], session["username"], "DECRYPT", "SUCCESS", f"Retrieved {row['original_name']}")
    return send_file(out, as_attachment=True, download_name=row["original_name"])

# ---- Module 4: Audit & Access Control ----
@app.route("/audit")
@login_required
def audit():
    conn = db()
    if session.get("role") == "admin":
        logs = conn.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100").fetchall()
    else:
        logs = conn.execute("SELECT * FROM audit_logs WHERE user_id=? ORDER BY id DESC LIMIT 100", (session["user_id"],)).fetchall()
    conn.close()
    return render_template("audit.html", logs=logs)

@app.route("/admin/users")
@login_required
@admin_required
def users_page():
    conn = db()
    users = conn.execute("SELECT id,username,role,created_at FROM users ORDER BY id").fetchall()
    conn.close()
    return render_template("users.html", users=users)

@app.route("/admin/overview")
@login_required
@admin_required
def admin_overview():
    conn = db()
    stats = {
        "users": conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "files": conn.execute("SELECT COUNT(*) FROM files").fetchone()[0],
        "logs": conn.execute("SELECT COUNT(*) FROM audit_logs").fetchone()[0],
        "avg_ms": conn.execute("SELECT COALESCE(AVG(encryption_ms),0) FROM files").fetchone()[0],
    }
    usage = conn.execute("SELECT algorithm, COUNT(*) count FROM files GROUP BY algorithm ORDER BY count DESC").fetchall()
    recent = conn.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 12").fetchall()
    conn.close()
    return render_template("admin.html", stats=stats, usage=usage, recent=recent)

@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="You do not have permission to access this resource."), 403

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="The requested resource was not found."), 404

@app.errorhandler(500)
def server_error(_):
    return render_template("error.html", code=500, message="The server could not complete that operation."), 500

if __name__ == "__main__":
    init_db()
    ensure_rsa_keys()
    app.run(debug=True)
