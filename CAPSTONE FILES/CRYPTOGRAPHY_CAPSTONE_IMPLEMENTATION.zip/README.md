# AI-Powered Adaptive Encryption System

A professional Flask prototype for the capstone project:

**AI-Powered Adaptive Encryption System for Intelligent Data Protection**

## Four modules

1. Secure User Registration and Intelligent File Management
2. AI-Based Adaptive Encryption Intelligence Engine
3. Adaptive Encryption and Secure File Storage
4. Audit Logging, Performance Monitoring and Access Control

## How the AI works

The prototype uses an explainable `DecisionTreeClassifier`. It receives:
- file type category
- file size category
- sensitivity: Low / Medium / High
- user priority: Speed / Balanced / Security

It predicts one of:
- AES-256-GCM
- ChaCha20-Poly1305
- Hybrid AES-256 + RSA-2048

The included training examples represent an explicit policy so the system is deterministic and easy to explain in a capstone review. For the final project, replace the policy-generated training set with a measured dataset containing encryption time, memory use, file characteristics, and security requirements.

## Security notes

- User passwords are stored as password hashes, not plaintext.
- AES-GCM and ChaCha20-Poly1305 provide authenticated encryption.
- Hybrid mode uses AES-256 for file data and RSA-2048 OAEP to protect the AES key.
- Per-file keys are wrapped before being stored.
- SHA-256 is used to verify decrypted file integrity.
- Filenames are sanitized.
- Role-based access control distinguishes `admin` and `user`.

This is a local academic prototype. For production deployment:
- store secrets in environment variables or a secrets manager
- use a KMS/HSM for key management
- use HTTPS
- add CSRF protection
- use object storage with private access
- avoid retaining decrypted files after download
- replace the demo ML policy dataset with measured experimental data

## Run on Windows

Open a terminal in this folder:

```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open:

`http://127.0.0.1:5000`

## Demo administrator

Username: `admin`
Password: `Admin@123`

Change the demo password before any real deployment.

## Project structure

- `app.py` — Flask backend, database, ML model and crypto engine
- `templates/` — professional UI
- `static/style.css` — cryptography-themed styling
- `storage/encrypted/` — encrypted files
- `storage/decrypted/` — temporary decrypted files
- `storage/keys/` — generated RSA key pair


## Transparent cryptographic workflow

After encryption the result page exposes:
1. AI recommendation and confidence
2. Key-generation status (secret key values remain hidden)
3. Encryption algorithm and parameters
4. SHA-256 integrity reference
5. **Save Encrypted File** — downloads a real `.aegis` ciphertext container
6. **Inspect Ciphertext** — shows cryptographic metadata and a hex preview of the actual ciphertext
7. **Decrypt & Download** — decrypts, verifies SHA-256 integrity, and returns the original file

The `.aegis` file is a JSON-based academic container carrying non-secret metadata and Base64-encoded ciphertext. It is not the original plaintext renamed.
